from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QComboBox, QPushButton

class AtlasGitterDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Atlas-Gittergenerator")
        layout = QVBoxLayout()

        layout.addWidget(QLabel("Wählen Sie den aktiven Layer (Inhalt):"))
        self.layer_combo = QComboBox()
        layout.addWidget(self.layer_combo)

        layout.addWidget(QLabel("Wählen Sie den Maßstab:"))
        self.scale_combo = QComboBox()
        layout.addWidget(self.scale_combo)

        layout.addWidget(QLabel("Layout-Format wählen:"))
        self.format_combo = QComboBox()
        self.format_combo.addItems(["quer", "hoch"])
        layout.addWidget(self.format_combo)

        self.run_button = QPushButton("Gitter erstellen")
        layout.addWidget(self.run_button)

        self.setLayout(layout)

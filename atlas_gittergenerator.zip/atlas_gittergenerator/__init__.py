def classFactory(iface):
    from .atlas_gittergenerator import AtlasGitterGenerator
    return AtlasGitterGenerator(iface)

# Resource file (normally generated with pyrcc5)
